var __defProp = Object.defineProperty;
var __defProps = Object.defineProperties;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropSymbols = Object.getOwnPropertySymbols;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __propIsEnum = Object.prototype.propertyIsEnumerable;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __spreadValues = (a, b) => {
  for (var prop in b || (b = {}))
    if (__hasOwnProp.call(b, prop))
      __defNormalProp(a, prop, b[prop]);
  if (__getOwnPropSymbols)
    for (var prop of __getOwnPropSymbols(b)) {
      if (__propIsEnum.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    }
  return a;
};
var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// apps/pollie-backend/index.ts
var pollie_backend_exports = {};
__export(pollie_backend_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(pollie_backend_exports);
var import_aws_sdk = require("aws-sdk");

// apps/pollie-backend/utils/index.ts
var multiUpdate = async ({
  tableName,
  partitionKeyName,
  partitionKeyValue,
  sortKeyName,
  sortKeyValue,
  db,
  updates
}) => {
  const keys = Object.keys(updates);
  const keyNameExpressions = keys.map((name) => `#${name}`);
  const keyValueExpressions = keys.map((value) => `:${value}`);
  const UpdateExpression = "set " + keyNameExpressions.map((nameExpr, idx) => `${nameExpr} = ${keyValueExpressions[idx]}`).join(", ");
  const ExpressionAttributeNames = keyNameExpressions.reduce((exprs, nameExpr, idx) => __spreadProps(__spreadValues({}, exprs), { [nameExpr]: keys[idx] }), {});
  const ExpressionAttributeValues = keyValueExpressions.reduce((exprs, valueExpr, idx) => __spreadProps(__spreadValues({}, exprs), { [valueExpr]: updates[keys[idx]] }), {});
  const params = {
    TableName: tableName,
    Key: { [partitionKeyName]: partitionKeyValue, [sortKeyName]: sortKeyValue },
    UpdateExpression,
    ExpressionAttributeNames,
    ExpressionAttributeValues
  };
  return db.update(params).promise();
};

// apps/pollie-backend/handlers/shared.ts
async function getVoteItems({
  body,
  dynamoDB: dynamoDB2,
  dbName: dbName2
}) {
  const getParams = JSON.parse(body);
  if (!getParams.userId) {
    throw new Error("No UserID provided for fetch");
  }
  const queryResult = await dynamoDB2.query({
    TableName: dbName2,
    KeyConditionExpression: `#source = :source and #data = :data`,
    ExpressionAttributeNames: {
      "#source": "source",
      "#data": "data"
    },
    ExpressionAttributeValues: {
      ":source": `user#${getParams.userId}`,
      ":data": "federalElection2022#votes"
    }
  }).promise();
  return queryResult;
}

// apps/pollie-backend/handlers/cast-vote.ts
async function castVote({ body, dynamoDB: dynamoDB2, dbName: dbName2 }) {
  var _a, _b;
  const data = JSON.parse(body);
  const individualVoteData = {
    [data.pollieName]: data.rating
  };
  let voteVariance = 0;
  let previousVote = void 0;
  try {
    const resultItems = await getVoteItems({
      body,
      dynamoDB: dynamoDB2,
      dbName: dbName2
    });
    if (resultItems == null ? void 0 : resultItems.Items) {
      resultItems.Items.some((e, i) => {
        if (e[data.pollieName]) {
          previousVote = e[data.pollieName];
          voteVariance = data.rating - previousVote;
          return true;
        }
      });
    }
    const voteResult = await multiUpdate({
      tableName: dbName2,
      partitionKeyName: "source",
      partitionKeyValue: `user#${data.userId}`,
      sortKeyName: "data",
      sortKeyValue: `federalElection2022#votes`,
      updates: individualVoteData,
      db: dynamoDB2
    });
    const counterResult = await dynamoDB2.update({
      TableName: dbName2,
      Key: {
        source: `federalElection2022#aggregates`,
        data: `politician#${data.pollieName}`
      },
      ReturnValues: "UPDATED_NEW",
      UpdateExpression: `SET #value1 = if_not_exists(#value1, :start) + :increment1, #value2 = if_not_exists(#value2, :start) + :increment2`,
      ExpressionAttributeValues: {
        ":start": 0,
        ":increment1": previousVote ? voteVariance : data.rating,
        ":increment2": previousVote ? 0 : 1
      },
      ExpressionAttributeNames: {
        "#value1": "accumulatedVoteCount",
        "#value2": "totalVotesCast"
      }
    }).promise();
    const averageRating = Math.round(((_a = counterResult.Attributes) == null ? void 0 : _a.accumulatedVoteCount) / ((_b = counterResult.Attributes) == null ? void 0 : _b.totalVotesCast) * 10) / 10;
    return {
      statusCode: 200,
      body: JSON.stringify(__spreadProps(__spreadValues({}, counterResult.Attributes), { averageRating }), null, 2)
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify(error, null, 2)
    };
  }
}

// apps/pollie-backend/handlers/get-votes.ts
async function getVotes({ body, dynamoDB: dynamoDB2, dbName: dbName2 }) {
  try {
    const queryResult = await getVoteItems({
      body,
      dynamoDB: dynamoDB2,
      dbName: dbName2
    });
    return {
      statusCode: 200,
      body: JSON.stringify(queryResult, null, 2)
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify(error, null, 2)
    };
  }
}

// apps/pollie-backend/index.ts
var dbName = process.env.DB_NAME;
var dynamoDB = new import_aws_sdk.DynamoDB.DocumentClient({
  apiVersion: "2012-08-10",
  region: "ap-southeast-2"
});
async function handler(event) {
  if (!dbName) {
    console.error("no dynamo table name found :(");
    return {
      statusCode: 500,
      body: "No Dynamo Table Found :("
    };
  }
  if (event.path === "/" && event.httpMethod === "POST" && event.body) {
    return await castVote({
      body: event.body,
      dynamoDB,
      dbName
    });
  }
  if (event.path === "/" && event.httpMethod === "GET" && event.body) {
    return await getVotes({
      body: event.body,
      dynamoDB,
      dbName
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
